import React, { useEffect, useMemo, useState } from "react";
import Plot from "react-plotly.js";
import type { Layout } from "plotly.js";
import type { AgsiRow } from "../api/client";
import { fetchAgsiData, scrapeAgsiSync, scrapeAgsiAsync, getTaskStatus } from "../api/client";

function toX(rows: AgsiRow[]) {
  return rows.map((r) => r.date);
}

export default function StorageDashboard() {
  const [zone, setZone] = useState("eu");
  const [pages, setPages] = useState<number>(20);

  const [rows, setRows] = useState<AgsiRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [taskId, setTaskId] = useState<string | null>(null);
  const [taskState, setTaskState] = useState<string | null>(null);
  const [taskResult, setTaskResult] = useState<any | null>(null);

  const layoutBase: Partial<Layout> = useMemo(
    () => ({
      autosize: true,
      margin: { l: 40, r: 20, t: 50, b: 40 },
      legend: { orientation: "h" },
    }),
    []
  );

  const load = async () => {
    setError(null);
    try {
      const data = await fetchAgsiData(zone, pages);
      setRows(data);
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? "Failed to fetch AGSI data");
    }
  };

  const scrapeSync = async () => {
    setError(null);
    try {
      const data = await scrapeAgsiSync(zone, pages);
      setRows(data);
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? "Failed to scrape (sync)");
    }
  };

  const scrapeAsync = async () => {
    setError(null);
    setTaskId(null);
    setTaskState(null);
    setTaskResult(null);

    try {
      const res = await scrapeAgsiAsync(zone, pages);
      setTaskId(res.task_id);
      setTaskState("PENDING");
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? "Failed to enqueue scrape (async)");
    }
  };

  // Poll celery task status if taskId set
  useEffect(() => {
    if (!taskId) return;

    let cancelled = false;
    const interval = setInterval(async () => {
      try {
        const s = await getTaskStatus(taskId);
        if (cancelled) return;

        setTaskState(s.state);
        if (s.ready) {
          setTaskResult(s.result);
          clearInterval(interval);
          // optional: refresh data after job
          await load();
        }
      } catch (e) {
        // ignore polling failures briefly
      }
    }, 2000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [taskId]);

  // initial load
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const x = toX(rows);
  const pct = rows.map((r) => r.full_pct ?? null);
  const gas = rows.map((r) => r.gas_in_storage_gwh ?? null);
  const inj = rows.map((r) => r.injection ?? null);
  const wdr = rows.map((r) => r.withdrawal ?? null);

  return (
    <section className="card">
      <div className="row">
        <h1>📦 Storage — AGSI</h1>

        <div className="controls">
          <label>
            Zone
            <select value={zone} onChange={(e) => setZone(e.target.value)}>
              <option value="eu">EU</option>
              <option value="de">DE</option>
              <option value="fr">FR</option>
              <option value="it">IT</option>
              <option value="nl">NL</option>
            </select>
          </label>

          <label>
            Pages
            <input
              type="number"
              min={1}
              value={pages}
              onChange={(e) => setPages(parseInt(e.target.value || "1", 10))}
            />
          </label>

          <button className="btn" onClick={load}>
            Fetch
          </button>

          <button className="btn" onClick={scrapeSync}>
            Scrape (sync)
          </button>

          <button className="btn" onClick={scrapeAsync}>
            Scrape (async)
          </button>
        </div>
      </div>

      {error && <div className="error">Error: {error}</div>}

      {taskId && (
        <div className="task">
          <strong>Task:</strong> {taskId} &nbsp; | &nbsp;
          <strong>Status:</strong> {taskState ?? "UNKNOWN"}
          {taskResult && (
            <>
              &nbsp; | &nbsp;<strong>Result:</strong> {JSON.stringify(taskResult)}
            </>
          )}
        </div>
      )}

      <div className="grid">
        <div className="plot-card">
          <Plot
            data={[
              {
                x,
                y: pct,
                type: "scatter",
                mode: "lines",
                name: "% Full",
              },
            ]}
            layout={{
              ...layoutBase,
              title: { text: `${zone.toUpperCase()} — % Full` },
              yaxis: { title: { text: "% Full" } },
              xaxis: { title: { text: "Date" } },
            }}
            style={{ width: "100%", height: "360px" }}
            config={{ displayModeBar: false }}
          />
        </div>

        <div className="plot-card">
          <Plot
            data={[
              { x, y: gas, type: "scatter", mode: "lines", name: "Gas in storage (GWh)" },
              { x, y: inj, type: "scatter", mode: "lines", name: "Injection" },
              { x, y: wdr, type: "scatter", mode: "lines", name: "Withdrawal" },
            ]}
            layout={{
              ...layoutBase,
              title: { text: `${zone.toUpperCase()} — Balances (GWh)` },
              xaxis: { title: { text: "Date" } },
            }}
            style={{ width: "100%", height: "360px" }}
            config={{ displayModeBar: false }}
          />
        </div>
      </div>

      <h2>Rows</h2>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>Date</th>
              <th>% Full</th>
              <th>Gas (GWh)</th>
              <th>Injection</th>
              <th>Withdrawal</th>
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, 200).map((r, i) => (
              <tr key={`${r.date}-${i}`}>
                <td>{r.date}</td>
                <td>{r.full_pct ?? ""}</td>
                <td>{r.gas_in_storage_gwh ?? ""}</td>
                <td>{r.injection ?? ""}</td>
                <td>{r.withdrawal ?? ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
