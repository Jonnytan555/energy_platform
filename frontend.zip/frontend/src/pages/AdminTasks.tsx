import React, { useEffect, useState } from "react";
import { adminWorkerStats, adminActiveTasks } from "../api/client";

export default function AdminTasks() {
  const [stats, setStats] = useState<any>(null);
  const [active, setActive] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setError(null);
    try {
      const [s, a] = await Promise.all([adminWorkerStats(), adminActiveTasks()]);
      setStats(s);
      setActive(a);
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? "Failed to load admin task info");
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <section className="card">
      <div className="row">
        <h1>🛠 Admin — Celery</h1>
        <button className="btn" onClick={load}>
          Refresh
        </button>
      </div>

      {error && <div className="error">Error: {error}</div>}

      <h2>Worker stats</h2>
      <pre className="pre">{JSON.stringify(stats, null, 2)}</pre>

      <h2>Active tasks</h2>
      <pre className="pre">{JSON.stringify(active, null, 2)}</pre>
    </section>
  );
}
