
class ScraperFactory:
    """
    Registry-based factory for creating scraper instances by name.
    """

    _registry = {}

    @classmethod
    def register(cls, name: str, scraper_cls):
        """Register a scraper class."""
        cls._registry[name.lower()] = scraper_cls

    @classmethod
    def create(cls, name: str, *args, **kwargs):
        """Create a scraper instance by name."""
        scraper_cls = cls._registry.get(name.lower())
        if scraper_cls is None:
            raise ValueError(f"Scraper '{name}' not registered.")
        return scraper_cls(*args, **kwargs)

    @classmethod
    def list_scrapers(cls):
        """Return all known scrapers."""
        return list(cls._registry.keys())
