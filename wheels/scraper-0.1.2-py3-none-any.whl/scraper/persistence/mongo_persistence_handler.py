import pandas as pd
from pymongo import MongoClient
from scraper.persistence.persistence_handler import PersistenceHandler
from datetime import datetime

class MongoPersistenceHandler(PersistenceHandler):

    def __init__(self, uri: str, db: str, collection: str, keys: list[str]):
        self.client = MongoClient(uri)
        self.db = self.client[db]
        self.collection = self.db[collection]
        self.keys = keys

    def handle(self, new_df, dropNa=True, dtype=None, created_date_column="CreatedDate", where=""):
        if new_df.empty:
            return pd.DataFrame()

        df = new_df.copy()

        # Always store raw documents with timestamp
        df[created_date_column] = datetime.utcnow()

        records = df.to_dict(orient="records")

        for rec in records:
            query = {k: rec[k] for k in self.keys}
            # Always insert new version instead of replacing
            self.collection.insert_one(rec)

        return df
