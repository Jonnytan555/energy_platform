import logging
import pandas as pd
import numpy as np
import sqlalchemy as sa
from decimal import Decimal
from scraper.persistence.persistence_handler import PersistenceHandler


class PostgresPersistenceHandler(PersistenceHandler):

    def __init__(
        self,
        db_host: str,
        db_name: str,
        user: str,
        password: str,
        table_name: str,
        schema: str,
        keys: list[str],
        columns_to_compare: list[str],
        version_column: str = "version",
        latest_column: str = "is_latest",
        port: int = 5432,
    ):
        self.db_host = db_host
        self.db_name = db_name
        self.user = user
        self.password = password
        self.table_name = table_name
        self.schema = schema
        self.keys = keys
        self.columns_to_compare = columns_to_compare
        self.version_column = version_column
        self.latest_column = latest_column
        self.port = port

    # ---------------- ENGINE ---------------- #

    def _get_engine(self):
        url = (
            f"postgresql+psycopg2://{self.user}:{self.password}"
            f"@{self.db_host}:{self.port}/{self.db_name}"
        )
        return sa.create_engine(url)

    # ---------------- MAIN ENTRY ---------------- #

    def handle(self, new_df, dropNa=True, dtype=None, created_date_column="CreatedDate", where: str = ""):
        if new_df is None or new_df.empty:
            logging.info("No data to persist.")
            return pd.DataFrame()

        new_df = new_df.copy()
        new_df[self.version_column] = 1
        new_df[self.latest_column] = True

        result_df = self._prepare_data(new_df, dropNa, dtype, where)

        if result_df.empty:
            logging.info("Nothing new or changed.")
            return pd.DataFrame()

        result_df[created_date_column] = pd.Timestamp.utcnow()

        result_df.to_sql(
            self.table_name,
            schema=self.schema,
            con=self._get_engine(),
            if_exists="append",
            index=False,
            dtype=dtype,
        )

        return result_df

    # ---------------- PREP DATA ---------------- #

    def _prepare_data(self, new_df, dropNa, dtype, where):
        engine = self._get_engine()

        existing_df = self._get_existing_records(where)

        new_df = new_df.replace({np.nan: None})
        existing_df = existing_df.replace({np.nan: None})

        new_records = self._get_new_records(existing_df, new_df, dropNa)
        changed_records = self._get_changed_records(existing_df, new_df)

        if not changed_records.empty:
            temp_name = f"{self.table_name}_temp_{pd.Timestamp.utcnow().strftime('%Y%m%d%H%M%S%f')}"

            changed_records.to_sql(
                temp_name,
                schema=self.schema,
                con=engine,
                if_exists="replace",
                index=False,
                dtype=dtype,
            )

            join_condition = " AND ".join(
                [f'target."{k}" = temp."{k}"' for k in self.keys]
            )

            sql = f"""
                UPDATE {self.schema}."{self.table_name}" AS target
                SET "{self.latest_column}" = FALSE
                FROM {self.schema}."{temp_name}" AS temp
                WHERE {join_condition};
            """

            with engine.begin() as conn:
                conn.execute(sa.text(sql))
                conn.execute(sa.text(f'DROP TABLE {self.schema}."{temp_name}"'))

        return pd.concat([new_records, changed_records], ignore_index=True)

    # ---------------- EXISTING RECORDS ---------------- #

    def _get_existing_records(self, where=""):
        cols = (
            self.keys
            + self.columns_to_compare
            + [self.version_column, self.latest_column]
        )
        col_list = ", ".join([f'"{c}"' for c in cols])

        sql = f"""
            SELECT {col_list} FROM (
                SELECT {col_list},
                       ROW_NUMBER() OVER (
                           PARTITION BY {",".join(self.keys)}
                           ORDER BY {self.version_column} DESC
                       ) AS rn
                FROM {self.schema}."{self.table_name}"
                {where}
            ) t
            WHERE rn = 1;
        """

        try:
            return pd.read_sql(sql, self._get_engine())
        except Exception:
            return pd.DataFrame(columns=cols)

    # ---------------- CHANGED / NEW ---------------- #

    def _get_new_records(self, old_df, new_df, dropNa):
        # Merge with indicator to detect new rows
        merged = pd.merge(old_df, new_df, on=self.keys, how="right", indicator=True)

        # Filter rows that only exist in NEW data
        new_records = merged.query('_merge == "right_only"').copy()

        # Rename compare columns (lname, addr, phone_number)
        for col in self.columns_to_compare:
            if f"{col}_y" in new_records.columns:
                new_records[col] = new_records[f"{col}_y"]

        # Drop all the helper/merge columns
        drop_cols = [
            c for c in new_records.columns
            if c.endswith("_x") or c.endswith("_y") or c == "_merge"
        ]
        new_records = new_records.drop(columns=drop_cols, errors="ignore")

        # Assign version + latest flags
        new_records[self.version_column] = 1
        new_records[self.latest_column] = True

        if dropNa:
            new_records = new_records.dropna()

        return new_records


    def _get_changed_records(self, old_df, new_df):
        merged = pd.merge(old_df, new_df, on=self.keys, how="inner", indicator=True)
        merged = merged.query('_merge == "both"')

        if merged.empty:
            return pd.DataFrame()

        changed = []
        for col in self.columns_to_compare:
            diff = merged[merged[f"{col}_x"] != merged[f"{col}_y"]]
            if not diff.empty:
                changed.append(diff)

        if not changed:
            return pd.DataFrame()

        df = pd.concat(changed).drop_duplicates()

        for col in self.columns_to_compare:
            df[col] = df[f"{col}_y"]

        df[self.version_column] = df[f"{self.version_column}_x"] + 1
        df[self.latest_column] = True

        drop_cols = [c for c in df.columns if c.endswith("_x") or c.endswith("_y") or c == "_merge"]
        df = df.drop(columns=drop_cols)

        return df
