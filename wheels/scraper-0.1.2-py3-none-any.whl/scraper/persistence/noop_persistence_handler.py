# scraper/persistence/noop_persistence_handler.py

import pandas as pd
from scraper.persistence.persistence_handler import PersistenceHandler


class NoOpPersistenceHandler(PersistenceHandler):
    """
    A persistence handler that simply returns the DataFrame unchanged.
    Useful for "fetch-only" APIs.
    """

    def handle(
        self,
        new_df: pd.DataFrame,
        dropNa: bool = True,
        dtype=None,
        created_date_column: str = "CreatedDate",
        where: str = "",
    ) -> pd.DataFrame:
        return new_df
